Registration modal is partially working
and login works with static value of array
  var person1=new credential("jatin","jatin");
  var person2=new credential("anuj","anuj");
  var person3=new credential("hello","hello");
  var person4=new credential("admin","admin");
  var person5=new credential("user","user");
  var credentialarray=[person1,person2,person3,person4,person5];
  var person6=new credential("newuser","newuser")

